var myXs = [];
var myYs = [];
var mySizes = [];
var myXMoves = [];
var myYMoves = [];
var x = 50;
var y = 50;
var mousex = -10;
var mousey = -10;
var i;

function setup() {
  createCanvas(600, 400);
  for (i = 0; i < 6; ++i) {
    myXs[i] = (50 * i) + 1;
    myYs[i] = (50 * i) + 1;
    mySizes[i] = 5 + (10 * i);
    if (i % 2 == 0){
      myXMoves[i] = Math.floor(Math.random() * 10);
      myYMoves[i] = Math.floor(Math.random() * 10);
    }
    else{
      myXMoves[i] = -(Math.floor(Math.random() * 10));
      myYMoves[i] = -(Math.floor(Math.random() * 10));
    }
  }
}

function draw() {
  background(0);
  createExit();
  createPlayer();
  createObstacles();
  createMouseCircle();

  movePlayer();
  moveCircles();
}

function mouseClicked() {
  mousex = mouseX;
  mousey = mouseY;
}

function createMouseCircle() {
  fill('blue');
  ellipse(mousex, mousey, 15, 50);
}

function createPlayer() {
  fill(24, 200, 29);
  circle(x, y, 50);
}

function createExit() {
  fill('white');
  rect(400, 370, 70, 50);
  fill('black');
  textSize(20);
  text('EXIT', 413, 390);
}

function movePlayer() {
  if (keyIsDown(83) && y < 400) {
    y += 10;
  } else if (keyIsDown(87) && y > 0) {
    y -= 10;
  }

  if (keyIsDown(65) && x > 0) {
    x -= 10;
  } else if (keyIsDown(68) && x < 600) {
    x += 10;
  }

  if ((x >= 400 && x <= 470) && y >= 370) {
    displayWin();
  }
}

function displayWin() {
  fill('white');
  textSize(100);
  text('YOU WIN!!!!', 25, 230);
}

function createObstacles() {
  for (var i = 0; i < 6; ++i) {
    if (i == 0){
      fill('red');
    }
    else if (i == 1){
      fill('orange');
    }
    else if (i == 2){
      fill('yellow');
    }
    else if (i == 3){
      fill('green');
    }
    else if (i == 4){
      fill('teal');
    }
    else if (i == 5){
      fill('purple');
    }
    circle(myXs[i], myYs[i], mySizes[i]);
  }
}

function moveCircles() {
  for (i = 0; i < 6; ++i){
    if (myXs[i] >= 600) {
      myXs[i] = 1;
    }
    if (myXs[i] <= 0) {
      myXs[i] = 599;
    }
    myXs[i] -= myXMoves[i];

    if (myYs[i] >= 400) {
      myYs[i] = 1;
    }
    if (myYs[i] <= 0) {
      myYs[i] = 399;
    }
    myYs[i] += myYMoves[i];
  }
}